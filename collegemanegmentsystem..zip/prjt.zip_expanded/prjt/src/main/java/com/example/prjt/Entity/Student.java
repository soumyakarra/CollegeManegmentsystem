package com.example.prjt.Entity;
import javax.persistence.*;


@Entity
@Table(name="student")

public class Student{
@Id
@Column(name="Student_id",length=50)
@GeneratedValue(strategy=GenerationType.AUTO)
private int studentid;
@Column(name="Student_name",length=50)
private String studentname;
@Column(name="Student_address",length=100)
private String studentaddress;
@Column(name="Student_branch",length=100)
private String studentbranch;
@Column(name="Student_fee",length=100)
private String studentfee;
private int mobile;

	public  Student(String studentname, String studentaddress,  String studentbranch, String studentfee, int mobile) {
	this.studentname = studentname;
	this.studentaddress = studentaddress;
	this.studentbranch = studentbranch;
	this.studentfee = studentfee;
	this.mobile = mobile;
}

public Student() {
	
}
public int getStudentid() {
	return studentid;
}

public void setStudentid(int studentid) {
	this.studentid = studentid;
}

public String getStudentname() {
	return studentname;
}

public void setStudentname(String studentname) {
	this.studentname = studentname;
}

public String getStudentaddress() {
	return studentaddress;
}

public void setStudentaddress(String studentaddress) {
	this.studentaddress = studentaddress;
}

public String getStudentbranch() {
	return studentbranch;
}

public void setStudentbranch(String studentbranch) {
	this.studentbranch = studentbranch;
}
public String getStudentfee() {
	return studentfee;
}

public void setStudentfee(String studentfee) {
	this.studentfee = studentfee;
}


public int getMobile() {
	return mobile;
}

public void setMobile(int mobile) {
	this.mobile = mobile;
}

@Override
public String toString() {
	return "StudentUpdateDTO [ studentid=" +  studentid + ",  studentname=" +  studentname + ",  studentaddress="
			+  studentaddress + ",studentbranch=" +  studentbranch + ", studentfee=" +  studentfee + ", mobile=" + mobile + "]";
}

}
