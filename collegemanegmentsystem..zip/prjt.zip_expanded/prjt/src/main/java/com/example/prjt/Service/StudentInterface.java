package com.example.prjt.Service;


import java.util.List;

import com.example.prjt.DTO.StudentDTO;
import com.example.prjt.DTO.StudentsaveDTO;
import com.example.prjt.DTO.StudentupdateDTO;

public interface StudentInterface {
String addStudent(StudentDTO studentSaveDTO);
List<StudentDTO>getAllStudent();
String updateStudents(StudentupdateDTO studentUpdateDTO);
boolean deleteStudent(int id);
String addStuddent(StudentsaveDTO studentSaveDTO);
String updateStudents1(StudentupdateDTO studentUpdateDTO);
}