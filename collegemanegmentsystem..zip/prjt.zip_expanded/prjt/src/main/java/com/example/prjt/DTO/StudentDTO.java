package com.example.prjt.DTO;
import javax.persistence.Column;

public class StudentDTO {
	private int Studentid;
	private String Studentaddress;
	private int mobile;
	private String Studentname;
	private String Studentbranch;
	private String Studentfee;
	public StudentDTO(int studentid, String studentname, String studentaddress, int mobile) {
		super();
		this.Studentid = Studentid;
		this.Studentname = Studentname;
		this.Studentaddress = Studentaddress;
		this.Studentbranch = Studentbranch;
		this.Studentfee = Studentfee;
		this.mobile = mobile;
	}
	public StudentDTO() 
	{
		
	}
	public int getStudentid() {
		return Studentid;
	}
	public void setStudentid(int studentid) {
		this.Studentid = studentid;
	}
	public String getStudentname() {
		return Studentname;
	}
	public void setStudentname(String studentname) {
		this.Studentname = studentname;
	}
	public String getStudentaddress() {
		return Studentaddress;
	}
	public void setStudentaddress(String studentaddress) {
		this.Studentaddress = studentaddress;
	}
	public String getStudentbranch() {
		return Studentbranch;
	}
	public void setStudentbranch(String studenbranch) {
		this.Studentbranch = Studentbranch;
		
	}
	public String getStudentfee() {
		return Studentfee;
	}
	public void setStudentfe(String studenfee) {
		this.Studentfee = Studentfee;
		
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "StudentDTO [studentid=" + Studentid + ", studentname=" + Studentname + ", studentaddress="
				+ Studentaddress + ",studentbranch=" + Studentbranch + ",studentfee=" + Studentfee+ ", mobile=" + mobile + "]";
	}

	}


