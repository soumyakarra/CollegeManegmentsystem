package com.example.prjt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjtApplication.class, args);
	}

}
