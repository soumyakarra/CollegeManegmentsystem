package com.example.prjt.DTO;
import javax.persistence.Column;
public class StudentsaveDTO {
	private String studentname;
	private String studentaddress;
	private int mobile;
	private String studentid;
	private String studentfee;
	private String studentbranch;

	public  StudentsaveDTO(String studentname, String studentaddress, int mobile) {
		this.studentname = studentname;
		this.studentaddress = studentaddress;
		this.mobile = mobile;
	}

	public StudentsaveDTO() {
		
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public String getStudentaddress() {
		return studentaddress;
	}

	public void setStudentaddress(String studentaddress) {
		this.studentaddress = studentaddress;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "StudentUpdateDTO [ studentid=" +  studentid + ",  studentname=" +  studentname + ",  studentaddress="
				+  studentaddress + ",studentbranch=" +  studentbranch + ", studentfee=" +  studentfee + ", mobile=" + mobile + "]";
	}
}


