package com.example.prjt.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.example.prjt.DTO.StudentDTO;
import com.example.prjt.DTO.StudentsaveDTO;
import com.example.prjt.DTO.StudentupdateDTO;
import com.example.prjt.Entity.Student;
import com.example.prjt.Repository.StudentRepository;


@Service
public class StudentServiceimpl implements StudentInterface{
 private static final StudentupdateDTO StudentUpdateDTO = null;
@Autowired
	private StudentRepository studentRepository;
private CrudRepository<Student, Integer> studentRepo;
private StudentDTO StudentupdateDTO;
 public String addStuddent(StudentsaveDTO studentSaveDTO)
 {
	 Student student=new Student();
	 studentSaveDTO.getStudentname();
	 studentSaveDTO.getStudentaddress();
	 studentSaveDTO.getMobile();
	 studentRepo.save(student);
	 return
			 student.getStudentname();
 }
public List<StudentDTO> getAllStudent()
{
	List<Student>getStudents=studentRepository.findAll();
	List<StudentDTO>studentDTOList=new ArrayList<StudentDTO>();
	for(Student a:getStudents)
	{
		StudentDTO studentDTO=new StudentDTO(
				a.getStudentid(),
				a.getStudentname(),
				a.getStudentaddress(),
			
				a.getMobile()
				);
		studentDTOList.add(studentDTO);
		}
		return studentDTOList;
	}

public <studentsupdateDTO> String updateStudents(studentsupdateDTO studentsupdateDTO)
{
	if(studentRepository.existsById(((StudentDTO) studentsupdateDTO).getStudentid()))
	{
		Student student=studentRepository.getById(StudentupdateDTO.getStudentid());
		student.setStudentname(StudentupdateDTO.getStudentname());
		student.setStudentaddress(StudentupdateDTO.getStudentaddress());
		student.setStudentbranch(StudentupdateDTO.getStudentbranch());
		student.setStudentfee(StudentupdateDTO.getStudentfee());
		student.setMobile(StudentupdateDTO.getMobile());
		studentRepository.save(student);
	}
	else
	{
		System.out.println("Customer id is not exsist!!");
	}
return null;	
}
public boolean deleteStudent(int id)
{
	if(studentRepository.existsById(id))
	{
		studentRepository.deleteById(id);
	}
	else
	{
		System.out.println("Student id notfound!!");
	}
	return true;
}
public String addStudent(StudentDTO studentSaveDTO) {
	// TODO Auto-generated method stub
	return null;
}
public String updateStudents1(com.example.prjt.DTO.StudentupdateDTO studentUpdateDTO) {
	// TODO Auto-generated method stub
	return null;
}
public String updateStudents(com.example.prjt.DTO.StudentupdateDTO studentUpdateDTO) {
	// TODO Auto-generated method stub
	return null;
}
}