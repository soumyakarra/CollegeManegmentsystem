package com.example.prjt.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.prjt.DTO.StudentDTO;
import com.example.prjt.DTO.StudentsaveDTO;
import com.example.prjt.DTO.StudentupdateDTO;
import com.example.prjt.Service.StudentInterface;


@RestController //It is used for sending the data.
@CrossOrigin  
@RequestMapping("api/v1/student")
public class Studentcontroller {
@Autowired
private StudentInterface customerService;
private Studentcontroller studentService;
private String saveStudent(@RequestBody StudentsaveDTO studentsaveDTO)
{
	String id=studentService.addStudent(studentsaveDTO);
	return id;
}
private String addStudent(StudentsaveDTO studentsaveDTO) {
	// TODO Auto-generated method stub
	return null;
}
@GetMapping(path="/getAllStudent")
public List<StudentDTO>getAllStudent()
{
	List<StudentDTO>allStudents=studentService.getAllStudent();
	return allStudents;
	}
@PutMapping(path="/update")
private String updateStudent(@RequestBody StudentupdateDTO studentupdateDTO)
{
	String id=studentService.updateStudent(studentupdateDTO);
	return id;
}
@DeleteMapping(path="/deletestudent/{id}")
public String deleteStudent(@PathVariable(value="id")int id)
{
String deletestudent=studentService.deleteStudent(id);
return "deleted";
}

}
