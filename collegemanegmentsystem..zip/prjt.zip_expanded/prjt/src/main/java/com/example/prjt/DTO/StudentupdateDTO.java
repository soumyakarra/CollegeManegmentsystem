package com.example.prjt.DTO;

public class StudentupdateDTO {
	private int studentid;
	private String studentname;
	private String studentaddress;
	private String studentbranch;
	private String studentfee;
	private int mobile;

			public  StudentupdateDTO(String studentname, String studentaddress,  String studentbranch, String studentfee, int mobile) {
				this.studentname = studentname;
				this.studentaddress = studentaddress;
				this.studentbranch = studentbranch;
				this.studentfee = studentfee;
				this.mobile = mobile;
			}

			public StudentupdateDTO() {
				
			}
			public int getStudentid() {
				return studentid;
			}

			public void setStudentid(int studentid) {
				this.studentid = studentid;
			}


			public String getStudentname() {
				return studentname;
			}

			public void setStudentname(String studentname) {
				this.studentname = studentname;
			}

			public String getStudentaddress() {
				return studentaddress;
			}

			public void setStudentaddress(String studentaddress) {
				this.studentaddress = studentaddress;
			}

			public  String getStudentbranch() {
				return studentbranch;
			}

			public void setStudentbranch(String studentbranch) {
				this.studentbranch = studentbranch;
			}
			public String getStudentfee() {
				return studentfee;
			}

			public void setStudentfee(String studentfee) {
				this.studentfee = studentfee;
			}


			public int getMobile() {
				return mobile;
			}

			public void setMobile(int mobile) {
				this.mobile = mobile;
			}

			@Override
			public String toString() {
				return "StudentUpdateDTO [ studentid=" +  studentid + ",  studentname=" +  studentname + ",  studentaddress="
						+  studentaddress + ",studentbranch=" +  studentbranch + ", studentfee=" +  studentfee + ", mobile=" + mobile + "]";
			}
}
